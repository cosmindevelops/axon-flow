--
-- PostgreSQL database dump
--

-- Dumped from database version 17.4 (Debian 17.4-1.pgdg120+2)
-- Dumped by pg_dump version 17.4 (Debian 17.4-1.pgdg120+2)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: axon; Type: SCHEMA; Schema: -; Owner: axon
--

CREATE SCHEMA axon;


ALTER SCHEMA axon OWNER TO axon;

--
-- Name: SCHEMA axon; Type: COMMENT; Schema: -; Owner: axon
--

COMMENT ON SCHEMA axon IS 'Axon Flow main application schema';


--
-- Name: uuid-ossp; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS "uuid-ossp" WITH SCHEMA public;


--
-- Name: EXTENSION "uuid-ossp"; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION "uuid-ossp" IS 'generate universally unique identifiers (UUIDs)';


--
-- Name: vector; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS vector WITH SCHEMA public;


--
-- Name: EXTENSION vector; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION vector IS 'vector data type and ivfflat and hnsw access methods';


--
-- Name: subscription_status; Type: TYPE; Schema: public; Owner: axon
--

CREATE TYPE public.subscription_status AS ENUM (
    'active',
    'cancelled',
    'past_due',
    'trialing'
);


ALTER TYPE public.subscription_status OWNER TO axon;

--
-- PostgreSQL database dump complete
--

